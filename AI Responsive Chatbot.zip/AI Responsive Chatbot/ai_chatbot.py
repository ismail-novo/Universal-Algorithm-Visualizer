import tkinter as tk
from tkinter import ttk, messagebox
import random
import time
import threading

# --- 🎨 ULTRA MODERN & MINIMALIST TOKYO-NIGHT THEME ---
BG_COLOR = "#1a1b26"        # Deep rich dark background
CARD_BG = "#24283b"         # Slightly lighter slate for panels
CANVAS_BG = "#16161e"       # Super dark for graph focus
TEXT_COLOR = "#a9b1d6"      # Soft lavender/white text
ACCENT_COLOR = "#7aa2f7"    # Sleek cyan-blue
SUCCESS_COLOR = "#9ece6a"   # Fresh lime green
ERROR_COLOR = "#f7768e"     # Pastel punch red
HIGHLIGHT_COLOR = "#e0af68" # Golden sunset yellow
BORDER_COLOR = "#414868"    # Subtle cyber-grid borders

# ইন-মেমোরি ডেটাবেস (অস্থায়ীভাবে ইউজার ডেটা সংরক্ষণের জন্য)
USER_DB = {"admin": "1234"}

class AuthManager:
    """লগইন এবং সাইন-আপ উইন্ডো হ্যান্ডেল করার জন্য ক্লাস"""
    def __init__(self, root, on_success_callback):
        self.root = root
        self.on_success_callback = on_success_callback
        self.root.title("Auth - Universal Algorithm Visualizer")
        self.root.geometry("400x500")
        self.root.config(bg=BG_COLOR)
        self.root.resizable(False, False)
        
        self.main_frame = tk.Frame(self.root, bg=BG_COLOR)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        self.show_login()

    def clear_frame(self):
        for widget in self.main_frame.winfo_children():
            widget.destroy()

    def show_login(self):
        self.clear_frame()
        
        # কার্ড কন্টেইনার
        card = tk.Frame(self.main_frame, bg=CARD_BG, bd=0, highlightthickness=1, highlightbackground=BORDER_COLOR)
        card.place(relx=0.5, rely=0.5, anchor="center", width=340, height=420)
        
        tk.Label(card, text="Welcome Back", font=("Helvetica Neue", 16, "bold"), bg=CARD_BG, fg="white").pack(pady=(30, 5))
        tk.Label(card, text="Login to your account", font=("Segoe UI", 9), bg=CARD_BG, fg=TEXT_COLOR).pack(pady=(0, 20))
        
        # ইউজারনেম
        tk.Label(card, text="Username", bg=CARD_BG, fg=TEXT_COLOR, font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=30, pady=(10, 2))
        username_entry = tk.Entry(card, bg=BG_COLOR, fg="white", bd=0, highlightthickness=1, highlightbackground=BORDER_COLOR, font=("Segoe UI", 10), insertbackground="white")
        username_entry.pack(fill=tk.X, padx=30, ipady=5)
        
        # পাসওয়ার্ড
        tk.Label(card, text="Password", bg=CARD_BG, fg=TEXT_COLOR, font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=30, pady=(10, 2))
        password_entry = tk.Entry(card, show="•", bg=BG_COLOR, fg="white", bd=0, highlightthickness=1, highlightbackground=BORDER_COLOR, font=("Segoe UI", 10), insertbackground="white")
        password_entry.pack(fill=tk.X, padx=30, ipady=5)
        
        def handle_login():
            uname = username_entry.get().strip()
            pw = password_entry.get().strip()
            
            if uname in USER_DB and USER_DB[uname] == pw:
                self.main_frame.pack_forget()
                self.on_success_callback() # ড্যাশবোর্ডে নিয়ে যাবে
            else:
                messagebox.showerror("Error", "Invalid username or password!", parent=self.root)

        # লগইন বাটন
        tk.Button(card, text="Login", command=handle_login, bg=ACCENT_COLOR, fg=BG_COLOR, font=("Segoe UI", 10, "bold"), relief=tk.FLAT, cursor="hand2").pack(fill=tk.X, padx=30, pady=25, ipady=4)
        
        # সাইন-আপ এ যাওয়ার অপশন
        switch_btn = tk.Button(card, text="Don't have an account? Sign Up", command=self.show_signup, bg=CARD_BG, fg=ACCENT_COLOR, bd=0, font=("Segoe UI", 9, "underline"), activebackground=CARD_BG, activeforeground=ACCENT_COLOR, cursor="hand2")
        switch_btn.pack(pady=10)

    def show_signup(self):
        self.clear_frame()
        
        card = tk.Frame(self.main_frame, bg=CARD_BG, bd=0, highlightthickness=1, highlightbackground=BORDER_COLOR)
        card.place(relx=0.5, rely=0.5, anchor="center", width=340, height=420)
        
        tk.Label(card, text="Create Account", font=("Helvetica Neue", 16, "bold"), bg=CARD_BG, fg="white").pack(pady=(30, 5))
        tk.Label(card, text="Get started for free", font=("Segoe UI", 9), bg=CARD_BG, fg=TEXT_COLOR).pack(pady=(0, 20))
        
        tk.Label(card, text="Choose Username", bg=CARD_BG, fg=TEXT_COLOR, font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=30, pady=(10, 2))
        username_entry = tk.Entry(card, bg=BG_COLOR, fg="white", bd=0, highlightthickness=1, highlightbackground=BORDER_COLOR, font=("Segoe UI", 10), insertbackground="white")
        username_entry.pack(fill=tk.X, padx=30, ipady=5)
        
        tk.Label(card, text="Create Password", bg=CARD_BG, fg=TEXT_COLOR, font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=30, pady=(10, 2))
        password_entry = tk.Entry(card, show="•", bg=BG_COLOR, fg="white", bd=0, highlightthickness=1, highlightbackground=BORDER_COLOR, font=("Segoe UI", 10), insertbackground="white")
        password_entry.pack(fill=tk.X, padx=30, ipady=5)
        
        def handle_signup():
            uname = username_entry.get().strip()
            pw = password_entry.get().strip()
            
            if not uname or not pw:
                messagebox.showerror("Error", "Fields cannot be empty!", parent=self.root)
                return
            
            if uname in USER_DB:
                messagebox.showerror("Error", "Username already exists!", parent=self.root)
            else:
                USER_DB[uname] = pw
                messagebox.showinfo("Success", "Account created successfully! Please login.", parent=self.root)
                self.show_login()

        tk.Button(card, text="Sign Up", command=handle_signup, bg=SUCCESS_COLOR, fg=BG_COLOR, font=("Segoe UI", 10, "bold"), relief=tk.FLAT, cursor="hand2").pack(fill=tk.X, padx=30, pady=25, ipady=4)
        
        switch_btn = tk.Button(card, text="Already have an account? Login", command=self.show_login, bg=CARD_BG, fg=ACCENT_COLOR, bd=0, font=("Segoe UI", 9, "underline"), activebackground=CARD_BG, activeforeground=ACCENT_COLOR, cursor="hand2")
        switch_btn.pack(pady=10)


class UltimateSimulator:
    def __init__(self, root):
        self.root = root
        self.root.title("Universal Algorithm Visualizer (BAUST CS)")
        self.root.geometry("1180x820") # আগের উইন্ডো সাইজ
        self.root.config(bg=BG_COLOR)
        self.root.resizable(True, True)

        # Simulation States
        self.data = []
        self.is_paused = False
        self.speed = 0.1
        self.next_step = False
        self.current_algo = ""

        self.apply_ttk_styles()
        self.setup_ui()

    def apply_ttk_styles(self):
        """Configure professional styles for dropdowns and widgets."""
        style = ttk.Style()
        style.theme_use("clam")
        
        style.configure("TCombobox", 
                        fieldbackground=CARD_BG, 
                        background=BORDER_COLOR, 
                        foreground="white", 
                        bordercolor=BORDER_COLOR, 
                        arrowcolor="white")
        
        style.map("TCombobox", fieldbackground=[("readonly", CARD_BG)], foreground=[("readonly", "white")])

    def setup_ui(self):
        # --- 🔝 Top Navigation Bar (Branding) ---
        self.header_frame = tk.Frame(self.root, bg=CARD_BG, height=65)
        self.header_frame.pack(fill=tk.X, side=tk.TOP, padx=0, pady=0)
        
        tk.Label(self.header_frame, text="Universal Algorithm Visualizer", 
                 bg=CARD_BG, fg="white", font=("Helvetica Neue", 18, "bold")).pack(side=tk.LEFT, padx=35, pady=18)
        
        tk.Label(self.header_frame, text="BAUST CSE • Level-3 Term-1", 
                 bg=CARD_BG, fg=ACCENT_COLOR, font=("Consolas", 11, "bold")).pack(side=tk.RIGHT, padx=35, pady=22)

        # --- ⚙️ Control Dashboard Card ---
        self.ctrl_frame = tk.Frame(self.root, bg=CARD_BG, bd=0, highlightthickness=1, highlightbackground=BORDER_COLOR)
        self.ctrl_frame.pack(fill=tk.X, side=tk.TOP, padx=30, pady=20)

        # Row 0: Selectors & Data Config
        tk.Label(self.ctrl_frame, text="📂 Category", bg=CARD_BG, fg=TEXT_COLOR, font=("Segoe UI", 10, "bold")).grid(row=0, column=0, padx=20, pady=15, sticky="w")
        self.cat_menu = ttk.Combobox(self.ctrl_frame, values=["Sorting", "Searching", "Data Structures"], width=15, state="readonly")
        self.cat_menu.current(0)
        self.cat_menu.grid(row=0, column=1, padx=5)
        self.cat_menu.bind("<<ComboboxSelected>>", self.update_algo_list)

        tk.Label(self.ctrl_frame, text="⚙️ Algorithm", bg=CARD_BG, fg=TEXT_COLOR, font=("Segoe UI", 10, "bold")).grid(row=0, column=2, padx=20, sticky="w")
        self.algo_menu = ttk.Combobox(self.ctrl_frame, width=22, state="readonly")
        self.algo_menu.grid(row=0, column=3, padx=5)
        self.update_algo_list()

        tk.Label(self.ctrl_frame, text="🔢 Size", bg=CARD_BG, fg=TEXT_COLOR, font=("Segoe UI", 10, "bold")).grid(row=0, column=4, padx=20, sticky="w")
        self.size_entry = tk.Entry(self.ctrl_frame, width=6, bg=BG_COLOR, fg="white", bd=0, highlightthickness=1, highlightbackground=BORDER_COLOR, font=("Segoe UI", 10), justify="center", insertbackground="white")
        self.size_entry.insert(0, "25")
        self.size_entry.grid(row=0, column=5, padx=5)

        btn_gen = tk.Button(self.ctrl_frame, text=" ✨ Generate Data ", command=self.generate_data, bg=ACCENT_COLOR, fg=BG_COLOR, 
                            font=("Segoe UI", 9, "bold"), relief=tk.FLAT, activebackground="#5a86e0", cursor="hand2")
        btn_gen.grid(row=0, column=6, padx=25)

        # Aesthetic Divider
        sep = tk.Frame(self.ctrl_frame, height=1, bd=0, bg=BORDER_COLOR)
        sep.grid(row=1, column=0, columnspan=7, sticky="ew", padx=20, pady=5)

        # Row 2: Playback Controls (Media Player Style)
        self.play_btn = tk.Button(self.ctrl_frame, text=" ▶ Run Simulation ", command=self.start_thread, bg=SUCCESS_COLOR, fg=BG_COLOR, 
                                  font=("Segoe UI", 10, "bold"), relief=tk.FLAT, cursor="hand2")
        self.play_btn.grid(row=2, column=0, columnspan=2, padx=20, pady=15, sticky="ew")

        tk.Button(self.ctrl_frame, text=" ⏸ Pause / Play ", command=self.toggle_pause, bg="#ff9e64", fg=BG_COLOR, 
                  font=("Segoe UI", 9, "bold"), relief=tk.FLAT, cursor="hand2").grid(row=2, column=2, padx=5)

        tk.Button(self.ctrl_frame, text=" ⏭ Next Step ", command=self.trigger_next, bg="#7dcfff", fg=BG_COLOR, 
                  font=("Segoe UI", 9, "bold"), relief=tk.FLAT, cursor="hand2").grid(row=2, column=3, padx=5)

        tk.Label(self.ctrl_frame, text="⏱ Speed (s)", bg=CARD_BG, fg=TEXT_COLOR, font=("Segoe UI", 10, "bold")).grid(row=2, column=4, padx=20, sticky="w")
        self.speed_scale = tk.Scale(self.ctrl_frame, from_=0.01, to=1.5, resolution=0.05, orient=tk.HORIZONTAL, 
                                     bg=CARD_BG, fg=TEXT_COLOR, length=150, highlightthickness=0, troughcolor=BG_COLOR, activebackground=ACCENT_COLOR)
        self.speed_scale.set(0.15)
        self.speed_scale.grid(row=2, column=5, columnspan=2, padx=5, sticky="w")

        # --- 📊 Futuristic Simulation Canvas ---
        canvas_container = tk.Frame(self.root, bg=BG_COLOR, highlightthickness=1, highlightbackground=BORDER_COLOR)
        canvas_container.pack(fill=tk.BOTH, expand=True, padx=30, pady=5)

        self.canvas = tk.Canvas(canvas_container, bg=CANVAS_BG, height=450, highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

        # --- ℹ️ Neon Status Display (Footer) ---
        self.info_frame = tk.Frame(self.root, bg=CARD_BG, bd=0, highlightthickness=1, highlightbackground=BORDER_COLOR)
        self.info_frame.pack(fill=tk.X, side=tk.BOTTOM, padx=30, pady=20)

        self.status_var = tk.StringVar(value="Status: 🟢 System Ready")
        tk.Label(self.info_frame, textvariable=self.status_var, font=("Consolas", 12, "bold"), bg=CARD_BG, fg=ACCENT_COLOR).pack(anchor="w", padx=30, pady=(15, 5))

        self.complexity_var = tk.StringVar(value="Complexity: --")
        tk.Label(self.info_frame, textvariable=self.complexity_var, font=("Consolas", 10), bg=CARD_BG, fg=TEXT_COLOR).pack(anchor="w", padx=30, pady=(0, 15))

    # --- UI LOGIC ---
    def update_algo_list(self, event=None):
        cat = self.cat_menu.get()
        if cat == "Sorting":
            list_val = ["Bubble Sort", "Selection Sort", "Insertion Sort", "Quick Sort", "Merge Sort"]
        elif cat == "Searching":
            list_val = ["Linear Search", "Binary Search (Sorted Data)"]
        elif cat == "Data Structures":
            list_val = ["Stack (Push/Pop UI)", "Queue (Enqueue/Dequeue UI)"]
        
        self.algo_menu['values'] = list_val
        self.algo_menu.current(0)

    def generate_data(self):
        try:
            size = int(self.size_entry.get())
            if size > 65: size = 65
        except: size = 25
        
        self.data = [random.randint(20, 380) for _ in range(size)]
        self.draw_bars(self.data, [ACCENT_COLOR] * len(self.data))
        self.status_var.set("Status: 📝 New dataset generated successfully.")

    def draw_bars(self, data, color_list):
        self.canvas.delete("all")
        c_height = self.canvas.winfo_height() if self.canvas.winfo_height() > 50 else 380
        c_width = self.canvas.winfo_width() if self.canvas.winfo_width() > 50 else 1100
        
        for y_grid in range(0, c_height, 40):
            self.canvas.create_line(0, y_grid, c_width, y_grid, fill="#24283b", width=0.5)

        x_width = c_width / (len(data) + 1)
        offset = x_width / 2
        spacing = x_width * 0.12

        for i, val in enumerate(data):
            x0 = i * x_width + offset + spacing
            y0 = c_height - val - 20
            x1 = (i + 1) * x_width + offset
            y1 = c_height - 20

            self.canvas.create_rectangle(x0+2, y0+2, x1+2, y1, fill="#0c0d14", outline="")
            self.canvas.create_rectangle(x0, y0, x1, y1, fill=color_list[i], outline=BORDER_COLOR)
            
            if len(data) <= 30:
                self.canvas.create_text(x0 + (x_width - spacing)/2, y0 - 15, text=str(val), fill="white", font=("Consolas", 8, "bold"))
                
        self.root.update_idletasks()

    # --- CONTROL LOGIC ---
    def toggle_pause(self):
        self.is_paused = not self.is_paused

    def trigger_next(self):
        self.is_paused = True
        self.next_step = True

    def check_sim_state(self):
        while self.is_paused:
            if self.next_step:
                self.next_step = False
                break
            time.sleep(0.1)
        time.sleep(self.speed_scale.get())

    def start_thread(self):
        algo = self.algo_menu.get()
        if not self.data and "Data Structures" not in self.cat_menu.get():
            messagebox.showwarning("No Data", "Please generate data first!")
            return
        
        if algo == "Bubble Sort": threading.Thread(target=self.bubble_sort, daemon=True).start()
        elif algo == "Selection Sort": threading.Thread(target=self.selection_sort, daemon=True).start()
        elif algo == "Insertion Sort": threading.Thread(target=self.insertion_sort, daemon=True).start()
        elif algo == "Quick Sort": threading.Thread(target=self.quick_sort_start, daemon=True).start()
        elif algo == "Merge Sort": threading.Thread(target=self.merge_sort_start, daemon=True).start()
        elif algo == "Linear Search": threading.Thread(target=self.linear_search, daemon=True).start()
        elif algo == "Binary Search (Sorted Data)": threading.Thread(target=self.binary_search, daemon=True).start()
        elif algo == "Stack (Push/Pop UI)": threading.Thread(target=self.visualize_stack, daemon=True).start()
        elif algo == "Queue (Enqueue/Dequeue UI)": threading.Thread(target=self.visualize_queue, daemon=True).start()

    # --- 🧱 ALGORITHMS ---

    def bubble_sort(self):
        self.complexity_var.set("Complexity: Time O(n²) | Space O(1)")
        n = len(self.data)
        for i in range(n):
            for j in range(n - i - 1):
                self.status_var.set(f"Bubble Sort: Swapping check -> [{self.data[j]} vs {self.data[j+1]}]")
                colors = [ACCENT_COLOR] * n
                colors[j] = HIGHLIGHT_COLOR
                colors[j+1] = HIGHLIGHT_COLOR
                self.draw_bars(self.data, colors)
                self.check_sim_state()

                if self.data[j] > self.data[j+1]:
                    self.data[j], self.data[j+1] = self.data[j+1], self.data[j]
                    colors[j] = ERROR_COLOR
                    colors[j+1] = ERROR_COLOR
                    self.draw_bars(self.data, colors)
                    self.check_sim_state()
        self.draw_bars(self.data, [SUCCESS_COLOR] * n)
        self.status_var.set("Status: 🎉 Bubble Sort process completed!")

    def selection_sort(self):
        self.complexity_var.set("Complexity: Time O(n²) | Space O(1)")
        n = len(self.data)
        for i in range(n):
            min_idx = i
            for j in range(i+1, n):
                self.status_var.set(f"Selection Sort: Scanning for minimum. Current min: {self.data[min_idx]}")
                colors = [ACCENT_COLOR] * n
                colors[j] = HIGHLIGHT_COLOR
                colors[min_idx] = ERROR_COLOR
                self.draw_bars(self.data, colors)
                self.check_sim_state()
                if self.data[j] < self.data[min_idx]:
                    min_idx = j
            self.data[i], self.data[min_idx] = self.data[min_idx], self.data[i]
        self.draw_bars(self.data, [SUCCESS_COLOR] * n)
        self.status_var.set("Status: 🎉 Selection Sort process completed!")

    def insertion_sort(self):
        self.complexity_var.set("Complexity: Time O(n²) | Space O(1)")
        for i in range(1, len(self.data)):
            key = self.data[i]
            j = i-1
            self.status_var.set(f"Insertion Sort: Placing {key} in sorted subset.")
            while j >= 0 and key < self.data[j]:
                colors = [ACCENT_COLOR] * len(self.data)
                colors[j+1] = ERROR_COLOR
                self.draw_bars(self.data, colors)
                self.check_sim_state()
                self.data[j+1] = self.data[j]
                j -= 1
            self.data[j+1] = key
        self.draw_bars(self.data, [SUCCESS_COLOR] * len(self.data))
        self.status_var.set("Status: 🎉 Insertion Sort process completed!")

    def quick_sort_start(self):
        self.complexity_var.set("Complexity: Time O(n log n) | Space O(log n)")
        self.quick_sort(0, len(self.data) - 1)
        self.draw_bars(self.data, [SUCCESS_COLOR] * len(self.data))
        self.status_var.set("Status: 🎉 Quick Sort Completed!")

    def quick_sort(self, low, high):
        if low < high:
            pivot_index = self.partition(low, high)
            self.quick_sort(low, pivot_index - 1)
            self.quick_sort(pivot_index + 1, high)

    def partition(self, low, high):
        pivot = self.data[high]
        self.status_var.set(f"Quick Sort: Choosing Pivot = {pivot}")
        i = low - 1

        for j in range(low, high):
            colors = [ACCENT_COLOR] * len(self.data)
            colors[j] = HIGHLIGHT_COLOR
            colors[high] = "#f7768e"
            self.draw_bars(self.data, colors)
            self.check_sim_state()

            if self.data[j] < pivot:
                i += 1
                self.data[i], self.data[j] = self.data[j], self.data[i]

        self.data[i + 1], self.data[high] = self.data[high], self.data[i + 1]
        return i + 1

    def merge_sort_start(self):
        self.complexity_var.set("Complexity: Time O(n log n) | Space O(n)")
        self.merge_sort(0, len(self.data) - 1)
        self.draw_bars(self.data, [SUCCESS_COLOR] * len(self.data))
        self.status_var.set("Status: 🎉 Merge Sort Completed!")

    def merge_sort(self, l, r):
        if l < r:
            m = (l + r) // 2
            self.merge_sort(l, m)
            self.merge_sort(m + 1, r)
            self.merge(l, m, r)

    def merge(self, l, m, r):
        left = self.data[l:m+1]
        right = self.data[m+1:r+1]
        
        i = j = 0
        k = l

        while i < len(left) and j < len(right):
            colors = [ACCENT_COLOR] * len(self.data)
            colors[k] = HIGHLIGHT_COLOR
            self.status_var.set(f"Merge Sort: Merging subarrays into index range [{l} to {r}]")
            self.draw_bars(self.data, colors)
            self.check_sim_state()

            if left[i] <= right[j]:
                self.data[k] = left[i]
                i += 1
            else:
                self.data[k] = right[j]
                j += 1
            k += 1

        while i < len(left):
            self.data[k] = left[i]
            i += 1
            k += 1

        while j < len(right):
            self.data[k] = right[j]
            j += 1
            k += 1

    def linear_search(self):
        self.complexity_var.set("Complexity: Time O(n) | Space O(1)")
        target = random.choice(self.data)
        self.status_var.set(f"Linear Search: Searching for target {target}")
        for i in range(len(self.data)):
            colors = [ACCENT_COLOR] * len(self.data)
            colors[i] = HIGHLIGHT_COLOR
            self.draw_bars(self.data, colors)
            self.check_sim_state()
            if self.data[i] == target:
                colors[i] = SUCCESS_COLOR
                self.draw_bars(self.data, colors)
                self.status_var.set(f"Linear Search: 🎯 Found target at index [{i}]")
                return
        self.status_var.set("Status: Linear search finished.")

    def binary_search(self):
        self.complexity_var.set("Complexity: Time O(log n) | Space O(1)")
        self.data.sort()
        self.draw_bars(self.data, [ACCENT_COLOR] * len(self.data))
        target = random.choice(self.data)
        self.status_var.set(f"Binary Search: Target {target}")
        low, high = 0, len(self.data)-1
        
        while low <= high:
            mid = (low + high) // 2
            colors = [ACCENT_COLOR] * len(self.data)
            colors[mid] = HIGHLIGHT_COLOR
            colors[low] = "#bb9af2"
            colors[high] = "#bb9af2"
            self.draw_bars(self.data, colors)
            self.check_sim_state()
            
            if self.data[mid] == target:
                colors[mid] = SUCCESS_COLOR
                self.draw_bars(self.data, colors)
                self.status_var.set(f"Binary Search: 🎯 Target found at index [{mid}]")
                return
            elif self.data[mid] < target: low = mid + 1
            else: high = mid - 1

    def visualize_stack(self):
        self.complexity_var.set("Stack Operations: Push O(1) | Pop O(1)")
        stack_data = []
        for _ in range(5):
            val = random.randint(30, 300)
            stack_data.append(val)
            self.status_var.set(f"Stack Operations: ⏫ PUSHING element ({val})")
            self.draw_bars(stack_data, [SUCCESS_COLOR] * len(stack_data))
            self.check_sim_state()

        for _ in range(5):
            popped = stack_data.pop()
            self.status_var.set(f"Stack Operations: ⏬ POPPING element ({popped})")
            self.draw_bars(stack_data, [ERROR_COLOR] * len(stack_data))
            self.check_sim_state()

    def visualize_queue(self):
        self.complexity_var.set("Queue Operations: Enqueue O(1) | Dequeue O(1)")
        queue_data = []
        for _ in range(5):
            val = random.randint(30, 300)
            queue_data.append(val)
            self.status_var.set(f"Queue Operations: ➡️ ENQUEUE element ({val})")
            self.draw_bars(queue_data, [SUCCESS_COLOR] * len(queue_data))
            self.check_sim_state()

        for _ in range(5):
            if queue_data:
                dequeued = queue_data.pop(0)
                self.status_var.set(f"Queue Operations: ⬅️ DEQUEUE element ({dequeued})")
                self.draw_bars(queue_data, [ERROR_COLOR] * len(queue_data))
                self.check_sim_state()

# --- 🚀 MAIN EXECUTION FLOW ---
if __name__ == "__main__":
    root = tk.Tk()
    
    # ড্যাশবোর্ড লোড করার জন্য কলব্যাক
    def load_app():
        app = UltimateSimulator(root)

    auth = AuthManager(root, load_app)
    root.mainloop()